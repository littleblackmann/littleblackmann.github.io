# SIGNAL FIELD 分享版

這個資料夾可以直接壓縮後傳給別人。對方解壓縮後只要雙擊 `INSTALL.cmd`。

安裝程式會：

- 自動找 Wallpaper Engine，找不到才請對方選擇資料夾
- 把桌布安裝到目前 Windows 使用者的 `myprojects\SignalField`
- 將本機遙測 agent 安裝到 `%LOCALAPPDATA%\SignalField`，不依賴壓縮檔原本的位置
- 若尚未安裝 PowerShell 7，先詢問是否用 winget 安裝
- 詢問是否建立「目前使用者」的開機啟動捷徑；不會碰其他使用者或系統服務

## 對方需要什麼

- Windows、Wallpaper Engine、可支援 WebGL2 的顯示卡
- 若要完整的即時硬體 HUD：PowerShell 7。安裝器會先詢問才安裝。
- NVIDIA 顯卡可顯示最完整的 GPU 溫度、功耗、時脈、風扇與 VRAM；其他顯卡不會讓桌布故障，但部分 GPU 欄位可能沒有數據。

## 隱私與網路

agent 只監聽 `127.0.0.1:8789`，外部網路無法直接連入。它只讀取這台電腦的遙測資料，資料不會上傳。

天氣與空氣品質會連 Open-Meteo；自動定位會連 ipapi.co。若不想讓定位服務依 IP 推測位置，請在 Wallpaper Engine 的設定中填寫「座標」，例如 `25.03, 121.56`。

請不要把自己的私人 ICS 日曆網址寫回這個分享資料夾後再傳出去。安裝後的個人設定位於 `%LOCALAPPDATA%\SignalField\holo-agent.config.txt`。

## 發布名稱

正式名稱是 **SIGNAL FIELD · 全息工作台**。它避開 Marvel、JARVIS、Arc Reactor 等系列名稱；這是一般命名檢索後挑選的原創描述名，但若未來要將它商品化或註冊商標，仍應做目標市場的正式商標檢索。
