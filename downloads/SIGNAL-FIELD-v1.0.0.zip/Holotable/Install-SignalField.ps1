# SIGNAL FIELD installer. Runs in Windows PowerShell 5.1 or later.
# It installs only into the current user's Wallpaper Engine project directory,
# LocalAppData, and optional per-user Startup folder. No administrator rights.
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$DisplayName = 'SIGNAL FIELD'
$ProjectFolderName = 'SignalField'
$AgentFolder = Join-Path $env:LOCALAPPDATA $ProjectFolderName
$StartupLink = Join-Path ([Environment]::GetFolderPath('Startup')) "$DisplayName agent.lnk"

function Write-Title([string]$Text) {
  Write-Host ''
  Write-Host $Text -ForegroundColor Cyan
}

function Read-YesNo([string]$Prompt, [bool]$DefaultYes) {
  $suffix = if ($DefaultYes) { '[Y/n]' } else { '[y/N]' }
  $answer = Read-Host "$Prompt $suffix"
  if ([string]::IsNullOrWhiteSpace($answer)) { return $DefaultYes }
  return $answer.Trim().ToLowerInvariant() -in @('y', 'yes')
}

function Get-UniquePaths([string[]]$Paths) {
  $seen = @{}
  $out = New-Object System.Collections.Generic.List[string]
  foreach ($path in $Paths) {
    if ($path -and (Test-Path -LiteralPath $path)) {
      $full = [IO.Path]::GetFullPath($path)
      if (-not $seen.ContainsKey($full)) { $seen[$full] = $true; $out.Add($full) }
    }
  }
  return @($out)
}

function Find-WallpaperEngineRoots {
  $paths = New-Object System.Collections.Generic.List[string]
  $steamRoots = New-Object System.Collections.Generic.List[string]
  foreach ($key in 'HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam') {
    try {
      $steamPath = (Get-ItemProperty -Path $key -ErrorAction Stop).SteamPath
      if ($steamPath) { $steamRoots.Add($steamPath) }
    } catch {}
  }
  foreach ($drive in (Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Root -match '^[A-Za-z]:\\$' })) {
    $steamRoots.Add((Join-Path $drive.Root 'Steam'))
    $steamRoots.Add((Join-Path $drive.Root 'Program Files (x86)\Steam'))
    $steamRoots.Add((Join-Path $drive.Root 'Program Files\Steam'))
  }
  foreach ($steam in (Get-UniquePaths $steamRoots.ToArray())) {
    $engine = Join-Path $steam 'steamapps\common\wallpaper_engine'
    if (Test-Path -LiteralPath (Join-Path $engine 'wallpaper32.exe')) {
      $paths.Add($engine)
    }
  }
  return @(Get-UniquePaths $paths.ToArray())
}

function Choose-WallpaperEngineRoot {
  $roots = @(Find-WallpaperEngineRoots)
  if ($roots.Count -eq 1) { return $roots[0] }
  if ($roots.Count -gt 1) {
    Write-Host 'Found more than one Wallpaper Engine installation:' -ForegroundColor Yellow
    for ($i = 0; $i -lt $roots.Count; $i++) { Write-Host ("  [{0}] {1}" -f ($i + 1), $roots[$i]) }
    do { $choice = Read-Host 'Choose a number' } while ($choice -notmatch '^\d+$' -or [int]$choice -lt 1 -or [int]$choice -gt $roots.Count)
    return $roots[[int]$choice - 1]
  }

  Write-Host 'Wallpaper Engine was not found automatically.' -ForegroundColor Yellow
  Write-Host 'Choose its wallpaper_engine folder (the folder containing wallpaper32.exe).' -ForegroundColor Yellow
  Add-Type -AssemblyName System.Windows.Forms
  $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
  $dialog.Description = 'Choose the Wallpaper Engine wallpaper_engine folder'
  $dialog.ShowNewFolderButton = $false
  if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { throw 'No Wallpaper Engine folder was selected.' }
  if (-not (Test-Path -LiteralPath (Join-Path $dialog.SelectedPath 'wallpaper32.exe'))) {
    throw 'That folder does not contain wallpaper32.exe.'
  }
  return $dialog.SelectedPath
}

function Get-PwshPath {
  $command = Get-Command pwsh.exe -ErrorAction SilentlyContinue
  if ($command) { return $command.Source }
  foreach ($path in @(
    "$env:ProgramFiles\PowerShell\7\pwsh.exe",
    "${env:ProgramFiles(x86)}\PowerShell\7\pwsh.exe",
    "$env:LOCALAPPDATA\Microsoft\WindowsApps\pwsh.exe"
  )) {
    if (Test-Path -LiteralPath $path) { return $path }
  }
  return $null
}

function Install-PowerShellIfApproved {
  $existing = Get-PwshPath
  if ($existing) { return $existing }

  Write-Host 'SIGNAL FIELD needs PowerShell 7 for its local telemetry agent.' -ForegroundColor Yellow
  Write-Host 'Windows PowerShell is present, but it cannot run the agent.' -ForegroundColor Yellow
  if (-not (Read-YesNo 'Install Microsoft PowerShell 7 with winget now?' $false)) { return $null }
  $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
  if (-not $winget) { throw 'winget is not installed. Install PowerShell 7 manually, then run INSTALL.cmd again.' }
  & $winget.Source install --id Microsoft.PowerShell --exact --source winget --accept-package-agreements --accept-source-agreements
  if ($LASTEXITCODE -ne 0) { throw 'PowerShell 7 installation did not complete.' }
  $installed = Get-PwshPath
  if (-not $installed) {
    throw 'PowerShell 7 was installed but is not visible yet. Close this window, open INSTALL.cmd again, and continue.'
  }
  return $installed
}

function Copy-FileRequired([string]$Source, [string]$Destination) {
  if (-not (Test-Path -LiteralPath $Source)) { throw "Package file is missing: $Source" }
  Copy-Item -LiteralPath $Source -Destination $Destination -Force
}

Write-Title 'SIGNAL FIELD - Wallpaper Engine installer'
Write-Host 'This installs the wallpaper for the current Windows user only.'
Write-Host 'It does not need administrator rights and does not send your telemetry anywhere.'

$engineRoot = Choose-WallpaperEngineRoot
$projectRoot = Join-Path $engineRoot 'projects\myprojects'
$targetProject = Join-Path $projectRoot $ProjectFolderName

if (Test-Path -LiteralPath $targetProject) {
  if (-not (Read-YesNo "An existing $DisplayName installation was found. Update its wallpaper files?" $true)) {
    Write-Host 'Nothing was changed.' -ForegroundColor Yellow
    exit 0
  }
}

Write-Title 'Installing wallpaper files'
New-Item -ItemType Directory -Path $targetProject -Force | Out-Null
foreach ($file in @('index.html', 'project.json', 'preview.jpg')) {
  Copy-FileRequired (Join-Path $PackageRoot $file) (Join-Path $targetProject $file)
}
Write-Host "Wallpaper installed: $targetProject" -ForegroundColor Green

Write-Title 'Installing local telemetry agent'
New-Item -ItemType Directory -Path $AgentFolder -Force | Out-Null
foreach ($file in @('holo-agent.ps1', 'start-holo-agent.vbs')) {
  Copy-FileRequired (Join-Path $PackageRoot $file) (Join-Path $AgentFolder $file)
}
$configTarget = Join-Path $AgentFolder 'holo-agent.config.txt'
if (-not (Test-Path -LiteralPath $configTarget)) {
  Copy-FileRequired (Join-Path $PackageRoot 'holo-agent.config.txt') $configTarget
} else {
  Write-Host "Keeping your existing calendar and process settings: $configTarget" -ForegroundColor DarkGray
}

$pwsh = Install-PowerShellIfApproved
if ($pwsh) {
  if (Read-YesNo 'Start the telemetry agent automatically when you sign in?' $true) {
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($StartupLink)
    $shortcut.TargetPath = Join-Path $env:SystemRoot 'System32\wscript.exe'
    $shortcut.Arguments = '"' + (Join-Path $AgentFolder 'start-holo-agent.vbs') + '"'
    $shortcut.WorkingDirectory = $AgentFolder
    $shortcut.Description = 'SIGNAL FIELD local telemetry agent'
    $shortcut.Save()
    Write-Host "Startup shortcut created: $StartupLink" -ForegroundColor Green
  }
  Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\wscript.exe') -ArgumentList ('"' + (Join-Path $AgentFolder 'start-holo-agent.vbs') + '"')
  Start-Sleep -Seconds 1
  try {
    $reply = Invoke-WebRequest -UseBasicParsing -TimeoutSec 5 'http://127.0.0.1:8789/'
    if ($reply.StatusCode -eq 200) { Write-Host 'Telemetry agent is running.' -ForegroundColor Green }
  } catch {
    Write-Host 'The wallpaper is installed, but the agent did not answer yet. Run start-holo-agent.vbs in LocalAppData\\SignalField if telemetry stays offline.' -ForegroundColor Yellow
  }
} else {
  Write-Host 'The wallpaper is installed. Telemetry will stay offline until PowerShell 7 is installed.' -ForegroundColor Yellow
}

Write-Title 'Done'
Write-Host 'Open Wallpaper Engine, refresh My Projects if necessary, then select SIGNAL FIELD.' -ForegroundColor Green
Write-Host 'For weather privacy, set your own coordinates in the wallpaper settings instead of leaving automatic location enabled.' -ForegroundColor DarkGray
