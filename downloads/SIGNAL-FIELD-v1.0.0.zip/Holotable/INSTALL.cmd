@echo off
setlocal
title SIGNAL FIELD Installer
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-SignalField.ps1"
set "exitCode=%ERRORLEVEL%"
echo.
if not "%exitCode%"=="0" echo Installation did not finish. Read the message above, then press any key to close.
if "%exitCode%"=="0" echo Installation finished. Press any key to close.
pause >nul
exit /b %exitCode%
