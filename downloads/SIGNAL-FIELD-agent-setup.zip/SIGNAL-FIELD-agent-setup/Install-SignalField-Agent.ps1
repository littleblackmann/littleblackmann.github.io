# SIGNAL FIELD local telemetry agent installer. It does not install or modify the wallpaper itself.
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$DisplayName = 'SIGNAL FIELD'
$AgentFolder = Join-Path $env:LOCALAPPDATA 'SignalField'
$StartupLink = Join-Path ([Environment]::GetFolderPath('Startup')) "$DisplayName agent.lnk"

function Write-Title([string]$Text) {
  Write-Host ''
  Write-Host $Text -ForegroundColor Cyan
}

function Read-YesNo([string]$Prompt, [bool]$DefaultYes) {
  $suffix = if ($DefaultYes) { '[Y/n]' } else { '[y/N]' }
  $answer = Read-Host "$Prompt $suffix"
  if ([string]::IsNullOrWhiteSpace($answer)) { return $DefaultYes }
  return $answer.Trim().ToLowerInvariant() -in @('y', 'yes')
}

function Get-PwshPath {
  $command = Get-Command pwsh.exe -ErrorAction SilentlyContinue
  if ($command) { return $command.Source }
  foreach ($path in @(
    "$env:ProgramFiles\PowerShell\7\pwsh.exe",
    "${env:ProgramFiles(x86)}\PowerShell\7\pwsh.exe",
    "$env:LOCALAPPDATA\Microsoft\WindowsApps\pwsh.exe"
  )) {
    if (Test-Path -LiteralPath $path) { return $path }
  }
  return $null
}

function Install-PowerShellIfApproved {
  $existing = Get-PwshPath
  if ($existing) { return $existing }

  Write-Host 'SIGNAL FIELD needs PowerShell 7 for its local telemetry agent.' -ForegroundColor Yellow
  if (-not (Read-YesNo 'Install Microsoft PowerShell 7 with winget now?' $false)) { return $null }
  $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
  if (-not $winget) { throw 'winget is not installed. Install PowerShell 7 manually, then run INSTALL-AGENT.cmd again.' }
  & $winget.Source install --id Microsoft.PowerShell --exact --source winget --accept-package-agreements --accept-source-agreements
  if ($LASTEXITCODE -ne 0) { throw 'PowerShell 7 installation did not complete.' }
  $installed = Get-PwshPath
  if (-not $installed) { throw 'PowerShell 7 was installed but is not visible yet. Close this window, open INSTALL-AGENT.cmd again, and continue.' }
  return $installed
}

function Copy-FileRequired([string]$Name, [string]$Destination) {
  $source = Join-Path $PackageRoot $Name
  if (-not (Test-Path -LiteralPath $source)) { throw "Package file is missing: $Name" }
  Copy-Item -LiteralPath $source -Destination $Destination -Force
}

Write-Title 'SIGNAL FIELD - Local telemetry setup'
Write-Host 'This installs only the local telemetry agent for the current Windows user.'
Write-Host 'It listens on 127.0.0.1 only. Hardware and process data are not uploaded.'

New-Item -ItemType Directory -Path $AgentFolder -Force | Out-Null
foreach ($file in @('holo-agent.ps1', 'start-holo-agent.vbs')) {
  Copy-FileRequired $file (Join-Path $AgentFolder $file)
}

$configTarget = Join-Path $AgentFolder 'holo-agent.config.txt'
if (-not (Test-Path -LiteralPath $configTarget)) {
  Copy-FileRequired 'holo-agent.config.txt' $configTarget
} else {
  Write-Host "Keeping your existing calendar and process settings: $configTarget" -ForegroundColor DarkGray
}

$pwsh = Install-PowerShellIfApproved
if (-not $pwsh) {
  Write-Host 'The agent was copied but cannot start until PowerShell 7 is installed.' -ForegroundColor Yellow
  exit 0
}

if (Read-YesNo 'Start the telemetry agent automatically when you sign in?' $true) {
  $shell = New-Object -ComObject WScript.Shell
  $shortcut = $shell.CreateShortcut($StartupLink)
  $shortcut.TargetPath = Join-Path $env:SystemRoot 'System32\wscript.exe'
  $shortcut.Arguments = '"' + (Join-Path $AgentFolder 'start-holo-agent.vbs') + '"'
  $shortcut.WorkingDirectory = $AgentFolder
  $shortcut.Description = 'SIGNAL FIELD local telemetry agent'
  $shortcut.Save()
  Write-Host "Startup shortcut created: $StartupLink" -ForegroundColor Green
}

Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\wscript.exe') -ArgumentList ('"' + (Join-Path $AgentFolder 'start-holo-agent.vbs') + '"')
Start-Sleep -Seconds 1
try {
  $reply = Invoke-WebRequest -UseBasicParsing -TimeoutSec 5 'http://127.0.0.1:8789/'
  if ($reply.StatusCode -eq 200) { Write-Host 'Telemetry agent is running. Your SIGNAL FIELD wallpaper can now connect.' -ForegroundColor Green }
} catch {
  Write-Host 'The agent was installed but did not answer yet. Restart Windows or run start-holo-agent.vbs in LocalAppData\SignalField.' -ForegroundColor Yellow
}
