<#
  SIGNAL FIELD · agent
  ------------------------------------------------------------------
  桌布跑在瀏覽器沙箱裡，拿不到作業系統的東西，也抓不了不給 CORS 的網址。
  這支程式在本機開一個極小的 HTTP 服務，把這些代辦掉：
    CPU / 記憶體 / GPU / 硬碟 / 網路吞吐 / 開機時間 / 前幾名程序 / 行事曆
  只綁 127.0.0.1，外面連不進來。

  背景執行：雙擊 start-holo-agent.vbs
  停止：工作管理員結束對應的 pwsh.exe / powershell.exe
#>
param([int]$Port = 8789)

$ErrorActionPreference = 'Continue'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path

# ============================ 設定 ============================
$script:IcsSources = @()
# 這支 agent 自己造成的雜訊、以及使用者不想看到的程序
$script:Exclude = @('WmiPrvSE','conhost','Idle','_Total')

function Read-Config {
  $cfg = Join-Path $Root 'holo-agent.config.txt'
  $script:IcsSources = @()
  $script:Exclude = @('WmiPrvSE','conhost','Idle','_Total')
  if (-not (Test-Path $cfg)) { return }
  foreach ($line in (Get-Content $cfg -Encoding UTF8)) {
    $t = $line.Trim()
    if ($t -eq '' -or $t.StartsWith('#')) { continue }
    if ($t -match '^EXCLUDE\s*=\s*(.*)$') {
      $script:Exclude += ($Matches[1] -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
      continue
    }
    $script:IcsSources += $t
  }
}
Read-Config

# ========================= 系統遙測 =========================
$script:hasNvidia = $null
$script:netPrev   = $null
$script:sysCache  = $null
$script:sysAt     = [datetime]::MinValue
# 延遲量測（5 秒一次就好，不要每次請求都 ping）
$script:pingMs    = $null
$script:pingAt    = [datetime]::MinValue
$script:pinger    = New-Object System.Net.NetworkInformation.Ping
# 本次開機以來的峰值
$script:peak      = @{ cpu = 0; gpu = 0; temp = 0; ram = 0 }

function Get-Latency {
  if (((Get-Date) - $script:pingAt).TotalSeconds -lt 5) { return $script:pingMs }
  $script:pingAt = Get-Date
  foreach ($target in @('1.1.1.1', '8.8.8.8')) {
    try {
      $r = $script:pinger.Send($target, 900)
      if ($r.Status -eq 'Success') { $script:pingMs = [int]$r.RoundtripTime; return $script:pingMs }
    } catch {}
  }
  $script:pingMs = $null
  return $null
}

function Get-Telemetry {
  if (((Get-Date) - $script:sysAt).TotalMilliseconds -lt 900) { return $script:sysCache }
  $o = [ordered]@{}

  # --- CPU ---
  try {
    $cpu = (Get-CimInstance Win32_Processor -ErrorAction Stop |
            Measure-Object -Property LoadPercentage -Average).Average
    if ($null -ne $cpu) { $o.cpu = [math]::Round([double]$cpu, 0) }
    $ci = Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($ci) {
      $o.cpuName    = ($ci.Name -replace '\s+', ' ').Trim()
      $o.cpuCores   = $ci.NumberOfCores
      $o.cpuThreads = $ci.NumberOfLogicalProcessors
      $o.cpuClock   = $ci.CurrentClockSpeed
    }
  } catch {}

  # --- 每個邏輯核心的負載 ---
  try {
    $per = Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor -ErrorAction Stop |
           Where-Object { $_.Name -ne '_Total' }
    $o.cores = @($per | Sort-Object { [int]$_.Name } | ForEach-Object { [int]$_.PercentProcessorTime })
  } catch {}

  # --- 記憶體 ---
  try {
    $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
    $tot = [double]$os.TotalVisibleMemorySize / 1MB
    $fre = [double]$os.FreePhysicalMemory / 1MB
    $o.ram      = [math]::Round(($tot - $fre) / $tot * 100, 0)
    $o.ramUsed  = [math]::Round($tot - $fre, 1)
    $o.ramTotal = [math]::Round($tot, 1)
    $o.bootTime = $os.LastBootUpTime.ToString('yyyy-MM-ddTHH:mm:ss')
    $o.uptimeMin = [int]((Get-Date) - $os.LastBootUpTime).TotalMinutes
  } catch {}

  # --- GPU (NVIDIA) ---
  if ($null -eq $script:hasNvidia) { $script:hasNvidia = [bool](Get-Command nvidia-smi -ErrorAction SilentlyContinue) }
  if ($script:hasNvidia) {
    try {
      $line = (& nvidia-smi --query-gpu=utilization.gpu,memory.used,memory.total,temperature.gpu,name,power.draw,clocks.sm,fan.speed `
                            --format=csv,noheader,nounits 2>$null | Select-Object -First 1)
      if ($line) {
        $f = $line -split '\s*,\s*'
        if ($f.Count -ge 5) {
          $o.gpu       = [math]::Round([double]$f[0], 0)
          $o.vramUsed  = [math]::Round([double]$f[1], 0)
          $o.vramTotal = [math]::Round([double]$f[2], 0)
          $o.gpuTemp   = [math]::Round([double]$f[3], 0)
          $o.gpuName   = ($f[4] -replace '^NVIDIA\s+', '').Trim()
          if ($f.Count -ge 6 -and $f[5] -match '^[\d.]+$') { $o.gpuWatt  = [math]::Round([double]$f[5], 0) }
          if ($f.Count -ge 7 -and $f[6] -match '^[\d.]+$') { $o.gpuClock = [math]::Round([double]$f[6], 0) }
          if ($f.Count -ge 8 -and $f[7] -match '^[\d.]+$') { $o.gpuFan   = [math]::Round([double]$f[7], 0) }
        }
      }
    } catch {}
  }

  # --- 硬碟讀寫 ---
  try {
    $d = Get-CimInstance Win32_PerfFormattedData_PerfDisk_PhysicalDisk -Filter "Name='_Total'" -ErrorAction Stop
    if ($d) {
      $o.diskRead  = [math]::Round([double]$d.DiskReadBytesPersec  / 1MB, 1)   # MB/s
      $o.diskWrite = [math]::Round([double]$d.DiskWriteBytesPersec / 1MB, 1)
    }
  } catch {}

  # --- 網路延遲 ---
  $lat = Get-Latency
  if ($null -ne $lat) { $o.ping = $lat }

  # --- 硬碟 ---
  try {
    $o.disks = @(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' -ErrorAction Stop | ForEach-Object {
      $t = [double]$_.Size; $f = [double]$_.FreeSpace
      if ($t -le 0) { return }
      [ordered]@{
        id    = $_.DeviceID
        used  = [math]::Round(($t - $f) / 1GB, 0)
        total = [math]::Round($t / 1GB, 0)
        pct   = [math]::Round(($t - $f) / $t * 100, 0)
      }
    })
  } catch {}

  # --- 網路吞吐（用兩次取樣的差） ---
  try {
    $now = Get-Date
    $ifs = Get-CimInstance Win32_PerfRawData_Tcpip_NetworkInterface -ErrorAction Stop |
           Where-Object { $_.Name -notmatch 'Loopback|isatap|Teredo|Pseudo' }
    $rx = ($ifs | Measure-Object -Property BytesReceivedPersec -Sum).Sum
    $tx = ($ifs | Measure-Object -Property BytesSentPersec -Sum).Sum
    if ($script:netPrev) {
      $dt = ($now - $script:netPrev.T).TotalSeconds
      if ($dt -gt 0.2) {
        $o.netDown = [math]::Round((($rx - $script:netPrev.RX) / $dt) / 1KB, 1)   # KB/s
        $o.netUp   = [math]::Round((($tx - $script:netPrev.TX) / $dt) / 1KB, 1)
      }
    }
    $script:netPrev = @{ T = $now; RX = $rx; TX = $tx }
  } catch {}

  # --- 程序 ---
  try {
    $all = Get-CimInstance Win32_PerfFormattedData_PerfProc_Process -ErrorAction Stop |
           Where-Object { $_.Name -ne '_Total' -and $_.Name -ne 'Idle' }
    $o.procCount = @($all).Count
    # 顯示用：把 pwsh#3 這種實例編號拿掉，濾掉 agent 自己與設定裡排除的名稱
    $shown = $all | Where-Object {
      $n = ($_.Name -replace '#\d+$', '')
      $_.IDProcess -ne $PID -and ($script:Exclude -notcontains $n)
    }
    # 效能計數器給的是「單核百分比」（多執行緒可能 >100），
    # 除以邏輯核心數換算成整機佔比，跟工作管理員看到的一致
    $lp = if ($o.cpuThreads) { [double]$o.cpuThreads } else { [double]$env:NUMBER_OF_PROCESSORS }
    if ($lp -lt 1) { $lp = 1 }
    $o.procs = @($shown | Sort-Object PercentProcessorTime -Descending | Select-Object -First 6 | ForEach-Object {
      [ordered]@{
        name = ($_.Name -replace '#\d+$', '')
        cpu  = [math]::Round([double]$_.PercentProcessorTime / $lp, 1)
        mem  = [math]::Round([double]$_.WorkingSetPrivate / 1MB, 0)
      }
    })
  } catch {}

  # --- 本次開機以來的峰值（agent 隨開機啟動，等同開機峰值）---
  foreach ($k in @(@('cpu','cpu'), @('gpu','gpu'), @('gpuTemp','temp'), @('ram','ram'))) {
    $src = $k[0]; $dst = $k[1]
    if ($o.Contains($src) -and $null -ne $o[$src]) {
      $v = [int]$o[$src]
      if ($v -gt $script:peak[$dst]) { $script:peak[$dst] = $v }
    }
  }
  $o.peak = [ordered]@{ cpu = $script:peak.cpu; gpu = $script:peak.gpu; temp = $script:peak.temp; ram = $script:peak.ram }

  $o.host = $env:COMPUTERNAME
  $o.ts   = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()

  $script:sysCache = $o
  $script:sysAt = Get-Date
  return $o
}

# ======================= iCalendar 解析 =======================
function Expand-IcsLines([string]$text) {
  $raw = $text -split "`r?`n"
  $out = New-Object System.Collections.Generic.List[string]
  foreach ($l in $raw) {
    if ($l.Length -gt 0 -and ($l[0] -eq ' ' -or $l[0] -eq "`t")) {
      if ($out.Count -gt 0) { $out[$out.Count-1] = $out[$out.Count-1] + $l.Substring(1) }
    } else { $out.Add($l) }
  }
  return $out
}
function Convert-IcsDate([string]$v) {
  if (-not $v) { return $null }
  $v = $v.Trim()
  try {
    if ($v -match '^(\d{4})(\d{2})(\d{2})$') {
      return [datetime]::new([int]$Matches[1], [int]$Matches[2], [int]$Matches[3], 0, 0, 0, [DateTimeKind]::Local)
    }
    if ($v -match '^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})(Z?)$') {
      $d = [datetime]::new([int]$Matches[1], [int]$Matches[2], [int]$Matches[3],
                           [int]$Matches[4], [int]$Matches[5], [int]$Matches[6],
                           $(if ($Matches[7] -eq 'Z') { [DateTimeKind]::Utc } else { [DateTimeKind]::Local }))
      if ($Matches[7] -eq 'Z') { return $d.ToLocalTime() }
      return $d
    }
  } catch {}
  return $null
}
function Unescape-Ics([string]$s) {
  if (-not $s) { return '' }
  return $s -replace '\\n', ' ' -replace '\\,', ',' -replace '\\;', ';' -replace '\\\\', '\'
}
function Expand-Occurrences($ev, [datetime]$winStart, [datetime]$winEnd) {
  $out = New-Object System.Collections.Generic.List[object]
  if (-not $ev.Start) { return $out }
  $dur = if ($ev.End) { $ev.End - $ev.Start } else { [timespan]::FromHours(1) }
  if ($dur.TotalSeconds -le 0) { $dur = [timespan]::FromMinutes(30) }
  $emit = {
    param($s)
    $e = $s + $dur
    if ($e -gt $winStart -and $s -lt $winEnd) {
      foreach ($x in $ev.ExDates) { if ([math]::Abs(($x - $s).TotalMinutes) -lt 1) { return } }
      $out.Add([pscustomobject]@{ Start=$s; End=$e; Summary=$ev.Summary; Location=$ev.Location; AllDay=$ev.AllDay })
    }
  }
  if (-not $ev.RRule) { & $emit $ev.Start; return $out }
  $r = @{}
  foreach ($kv in ($ev.RRule -split ';')) { $p = $kv -split '=', 2; if ($p.Count -eq 2) { $r[$p[0].ToUpper()] = $p[1] } }
  $freq     = $r['FREQ']
  $interval = if ($r['INTERVAL']) { [int]$r['INTERVAL'] } else { 1 }
  if ($interval -lt 1) { $interval = 1 }
  $limit    = if ($r['COUNT']) { [int]$r['COUNT'] } else { 0 }
  $until    = if ($r['UNTIL']) { Convert-IcsDate $r['UNTIL'] } else { $null }
  $byday    = if ($r['BYDAY']) { ($r['BYDAY'] -split ',') | ForEach-Object { ($_ -replace '^[+-]?\d+', '').ToUpper() } } else { @() }
  $dayMap   = @{ 'SU'=0; 'MO'=1; 'TU'=2; 'WE'=3; 'TH'=4; 'FR'=5; 'SA'=6 }
  $cur = $ev.Start; $n = 0
  for ($i = 0; $i -lt 800; $i++) {
    if ($cur -gt $winEnd) { break }
    if ($until -and $cur -gt $until) { break }
    if ($freq -eq 'WEEKLY' -and $byday.Count -gt 0) {
      $weekStart = $cur.Date.AddDays(-[int]$cur.DayOfWeek)
      foreach ($d in $byday) {
        if (-not $dayMap.ContainsKey($d)) { continue }
        $occ = $weekStart.AddDays($dayMap[$d]).Add($cur.TimeOfDay)
        if ($occ -lt $ev.Start) { continue }
        if ($until -and $occ -gt $until) { continue }
        & $emit $occ; $n++
        if ($limit -gt 0 -and $n -ge $limit) { break }
      }
    } else { & $emit $cur; $n++ }
    if ($limit -gt 0 -and $n -ge $limit) { break }
    switch ($freq) {
      'DAILY'   { $cur = $cur.AddDays($interval) }
      'WEEKLY'  { $cur = $cur.AddDays(7 * $interval) }
      'MONTHLY' { $cur = $cur.AddMonths($interval) }
      'YEARLY'  { $cur = $cur.AddYears($interval) }
      default   { return $out }
    }
  }
  return $out
}
function Read-IcsSource([string]$src) {
  if ($src -match '^https?://') { return (Invoke-WebRequest -Uri $src -UseBasicParsing -TimeoutSec 20).Content }
  if (Test-Path $src) { return (Get-Content $src -Raw -Encoding UTF8) }
  throw "找不到來源：$src"
}
function Get-Events {
  $winStart = (Get-Date).AddHours(-2)
  $winEnd   = (Get-Date).AddDays(14)
  $all  = New-Object System.Collections.Generic.List[object]
  $errs = New-Object System.Collections.Generic.List[string]
  foreach ($src in $script:IcsSources) {
    try {
      $lines = Expand-IcsLines (Read-IcsSource $src)
      $ev = $null
      foreach ($line in $lines) {
        if ($line -eq 'BEGIN:VEVENT') {
          $ev = [pscustomobject]@{ Start=$null; End=$null; Summary=''; Location=''; RRule=$null; AllDay=$false; ExDates=@() }
          continue
        }
        if ($line -eq 'END:VEVENT') {
          if ($ev) { foreach ($o in (Expand-Occurrences $ev $winStart $winEnd)) { $all.Add($o) } }
          $ev = $null; continue
        }
        if (-not $ev) { continue }
        $idx = $line.IndexOf(':')
        if ($idx -lt 1) { continue }
        $key = $line.Substring(0, $idx); $val = $line.Substring($idx + 1)
        switch (($key -split ';')[0].ToUpper()) {
          'DTSTART' { $ev.Start = Convert-IcsDate $val; if ($key -match 'VALUE=DATE(?!-)') { $ev.AllDay = $true } }
          'DTEND'   { $ev.End   = Convert-IcsDate $val }
          'SUMMARY' { $ev.Summary  = Unescape-Ics $val }
          'LOCATION'{ $ev.Location = Unescape-Ics $val }
          'RRULE'   { $ev.RRule = $val }
          'EXDATE'  { $ev.ExDates = @($ev.ExDates) + @($val -split ',' | ForEach-Object { Convert-IcsDate $_ } | Where-Object { $_ }) }
        }
      }
    } catch { $errs.Add(("{0}：{1}" -f ($src -replace '/[^/]*$', '/…'), $_.Exception.Message)) }
  }
  $sorted = $all | Sort-Object Start | Select-Object -First 20
  return [pscustomobject]@{
    events = @(foreach ($e in $sorted) {
      [ordered]@{
        start   = $e.Start.ToString('yyyy-MM-ddTHH:mm:ss')
        end     = $e.End.ToString('yyyy-MM-ddTHH:mm:ss')
        summary = $e.Summary
        allDay  = [bool]$e.AllDay
      }
    })
    sources = $script:IcsSources.Count
    errors  = @($errs)
  }
}
$script:calCache = $null
$script:calAt    = [datetime]::MinValue
function Get-EventsCached {
  if ($script:calCache -and ((Get-Date) - $script:calAt).TotalMinutes -lt 5) { return $script:calCache }
  Read-Config
  $script:calCache = Get-Events
  $script:calAt = Get-Date
  return $script:calCache
}

# ====================== 極簡 HTTP 伺服器 ======================
# 單一實例保護：TcpListener 在 .NET Core 上不獨佔位址，光靠綁埠擋不住第二份
$mutexName = "Local\wallpaper-agent-$Port"
$createdNew = $false
$script:mutex = New-Object System.Threading.Mutex($true, $mutexName, [ref]$createdNew)
if (-not $createdNew) {
  Write-Host "已經有一份在 127.0.0.1:$Port 上跑了，這次不重複啟動。" -ForegroundColor Yellow
  exit 0
}

try {
  $listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, $Port)
  $listener.ExclusiveAddressUse = $true
  $listener.Start()
} catch {
  Write-Host "無法在 127.0.0.1:$Port 開啟服務 —— 可能已經有一份在跑了。" -ForegroundColor Yellow
  exit 1
}
function Send-Response($stream, [string]$body) {
  $b = [Text.Encoding]::UTF8.GetBytes($body)
  $head = "HTTP/1.1 200 OK`r`n" +
          "Content-Type: application/json; charset=utf-8`r`n" +
          "Access-Control-Allow-Origin: *`r`n" +
          "Cache-Control: no-store`r`n" +
          "Content-Length: $($b.Length)`r`n" +
          "Connection: close`r`n`r`n"
  $h = [Text.Encoding]::ASCII.GetBytes($head)
  $stream.Write($h, 0, $h.Length); $stream.Write($b, 0, $b.Length); $stream.Flush()
}

Write-Host "SIGNAL FIELD agent  →  http://127.0.0.1:$Port/   (Ctrl+C 停止)" -ForegroundColor Cyan
[void](Get-Telemetry)   # 先跑一次，讓網路差值有基準
Write-Host ("行事曆來源 {0} 個" -f $script:IcsSources.Count)

while ($true) {
  $client = $null
  try {
    $client = $listener.AcceptTcpClient()
    $client.ReceiveTimeout = 3000
    $stream = $client.GetStream()
    $buf = New-Object byte[] 4096
    $n = $stream.Read($buf, 0, $buf.Length)
    $req = if ($n -gt 0) { [Text.Encoding]::ASCII.GetString($buf, 0, $n) } else { '' }
    $path = '/'
    if ($req -match '^\w+\s+(\S+)') { $path = ($Matches[1] -split '\?')[0].TrimEnd('/') }
    if ($path -eq '') { $path = '/' }

    if ($path -eq '/calendar') {
      Send-Response $stream ((Get-EventsCached) | ConvertTo-Json -Depth 6 -Compress)
    } else {
      $t = Get-Telemetry
      Send-Response $stream ($t | ConvertTo-Json -Depth 6 -Compress)
    }
  } catch {
  } finally {
    if ($client) { try { $client.Close() } catch {} }
  }
}
