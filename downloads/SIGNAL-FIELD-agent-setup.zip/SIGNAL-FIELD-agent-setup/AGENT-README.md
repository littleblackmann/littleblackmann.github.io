# SIGNAL FIELD · 本機遙測 Agent

這個小安裝包只負責讓 SIGNAL FIELD 讀取本機 CPU、記憶體、GPU、硬碟、網路與程序資料；不會安裝或覆蓋 Wallpaper Engine 的桌布。

## Steam 使用者

1. 在 Steam Workshop 訂閱 SIGNAL FIELD。
2. 解壓縮本安裝包後，雙擊 `INSTALL-AGENT.cmd`。
3. 看到「登入時自動啟動」時直接按 Enter（預設為是）。
4. 回到 Wallpaper Engine；幾秒後 HUD 的「遙測連線」會顯示「已連線」。

安裝一次後，往後每次登入 Windows 都會自動啟動。本機 agent 對 Steam Workshop 版與完整下載版共用。

## 隱私

agent 只監聽 `127.0.0.1:8789`，外部網路不能直接連入。它只讀取這台電腦的遙測資料，不會上傳硬體或程序資料。天氣與空氣品質服務例外，詳見完整作品頁。
