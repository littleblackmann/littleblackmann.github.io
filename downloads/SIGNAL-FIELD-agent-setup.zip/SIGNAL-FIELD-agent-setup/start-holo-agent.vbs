' SIGNAL FIELD - start the local agent in the background (no window)
' Double-click to run. To stop: end pwsh.exe in Task Manager.
' NOTE: this file is intentionally pure ASCII. Windows Script Host reads
' .vbs as ANSI unless there is a BOM, so non-ASCII text breaks the parser.
Option Explicit
Dim sh, fso, dir, ps1, exe, cmd, c, i, cands
Set sh  = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

dir = fso.GetParentFolderName(WScript.ScriptFullName)
ps1 = """" & dir & "\holo-agent.ps1"""

cands = Array( _
  sh.ExpandEnvironmentStrings("%ProgramFiles%\PowerShell\7\pwsh.exe"), _
  sh.ExpandEnvironmentStrings("%ProgramFiles(x86)%\PowerShell\7\pwsh.exe"), _
  sh.ExpandEnvironmentStrings("%LOCALAPPDATA%\Microsoft\WindowsApps\pwsh.exe"))

exe = ""
For i = 0 To UBound(cands)
  c = cands(i)
  If exe = "" And fso.FileExists(c) Then exe = """" & c & """"
Next

If exe = "" Then
  MsgBox "PowerShell 7 (pwsh.exe) not found." & vbCrLf & _
         "This agent needs PowerShell 7; the built-in 5.1 cannot parse it." & vbCrLf & vbCrLf & _
         "Install with:  winget install Microsoft.PowerShell", _
         vbExclamation, "SIGNAL FIELD agent"
  WScript.Quit 1
End If

cmd = exe & " -NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File " & ps1
sh.Run cmd, 0, False
