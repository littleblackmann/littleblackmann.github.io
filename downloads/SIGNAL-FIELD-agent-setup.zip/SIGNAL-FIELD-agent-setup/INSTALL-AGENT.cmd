@echo off
setlocal
title SIGNAL FIELD - Telemetry Agent Setup
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-SignalField-Agent.ps1"
set "exitCode=%ERRORLEVEL%"
if not "%exitCode%"=="0" (
  echo.
  echo Setup did not complete. Read the message above, then press any key to close.
  pause >nul
)
exit /b %exitCode%
